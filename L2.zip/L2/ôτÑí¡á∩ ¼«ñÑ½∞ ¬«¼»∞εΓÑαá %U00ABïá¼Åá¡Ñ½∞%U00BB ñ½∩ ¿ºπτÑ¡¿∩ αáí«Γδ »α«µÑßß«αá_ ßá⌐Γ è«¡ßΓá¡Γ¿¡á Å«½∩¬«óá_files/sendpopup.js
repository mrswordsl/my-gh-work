if (!String.prototype.trim) {
 String.prototype.trim=function(){return this.replace(/^\s+|\s+$/g, '');};
}
function checkRegexp( o, regexp ) {
  return regexp.test( o.value );
}
//-------------------------------------
// checkPopup
//-------------------------------------
function checkPopup() {
//  var subject = decodeURIComponent(window.location.search.substring(1));
  var subject = document.sendform["subject"];
  var name = document.sendform["name"];
  var email = document.sendform["email"];
  var message = document.sendform["message"];
  name.className = '';
  email.className = '';
  message.className = '';
  if ( name.value.trim() == "" ) {
    name.className = 'err-content';
    alert ("Пожалуйста, введите ваше имя.");
    name.focus();
    return false;
    }
  if ( email.value.trim() == "" ) {
    email.className = 'err-content';
    alert ("Пожалуйста, введите адрес электронной почты.");
    email.focus();
    return false;
    }
  if ( ! checkRegexp(email, /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i ) ) {
    email.className = 'err-content';
    alert ("Неверный адрес электронной почты.");
    return false;
    }
  if ( message.value.trim() == "" ) {
    message.className = 'err-content';
    alert ("Пожалуйста, введите текст сообщения.");
    message.focus();
    return false;
    }
  openFormResults( {name: name.value, email: email.value,
                    subject: subject.value, message: message.value  } );
  return true;
}
//-------------------------------------
// openFormResults
//-------------------------------------
function openFormResults( postData ){
  $.post(
    'http://kpolyakov.spb.ru/php/sendform.php', postData,
    function(data) {
      var p = document.getElementById("popup");
      p.style.visibility = 'hidden';
      if ( data.indexOf('1') >= 0 )
           p = document.getElementById("send-ok");
      else p = document.getElementById("send-err");
      p.style.visibility = 'visible';
  });
}
Number.prototype.div = function(by){return (this - this % by) / by;};
//-------------------------------------
// getPageScroll
//-------------------------------------
var getPageScroll = (window.pageXOffset != undefined) ?
  function() {
    return {
      left: pageXOffset,
      top: pageYOffset
    };
  } :
  function() {
    var html = document.documentElement;
    var body = document.body;
    var top = html.scrollTop || body && body.scrollTop || 0;
    top -= html.clientTop;
    var left = html.scrollLeft || body && body.scrollLeft || 0;
    left -= html.clientLeft;
    return { top: top, left: left };
  };

//-------------------------------------
// size of viewport
//-------------------------------------
function vpWidth() {
return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
}
function vpHeight() {
return window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
}
//-------------------------------------
// showPopup
//-------------------------------------
function showPopup(subject, prompt) {
  var scrXY = getPageScroll();

  var subj_header = document.getElementById("subject-header");
  subj_header.innerHTML = subject;
  var subj = document.sendform["subject"];
  subj.value = subject;

  if ( prompt ) {
    var prmpt = document.getElementById("prompt");
    prmpt.innerHTML = prompt;
  }   

  var c = document.getElementById("popupdiv");
  c.style.visibility = "visible";

  var w = vpWidth();  //document.body.clientWidth;
  var h = vpHeight(); //document.body.clientHeight;

  c.style.width = w;
  c.style.height = document.body.scrollHeight;

  var p = document.getElementById("popup");
  p.style.left = scrXY.left + (w - p.offsetWidth).div(2) + 'px';
  p.style.top  = scrXY.top + (h - p.offsetHeight).div(2) + 'px';
  p.style.visibility = "visible";

  p = document.getElementById("send-ok");
  p.style.left = scrXY.left + (w - p.offsetWidth).div(2);
  p.style.top  = scrXY.top + (h - p.offsetHeight).div(2);

  p = document.getElementById("send-err");
  p.style.left = scrXY.left + (w - p.offsetWidth).div(2);
  p.style.top  = scrXY.top + (h - p.offsetHeight).div(2);
}
//-------------------------------------
// hidePopup
//-------------------------------------
function hidePopup() {
  var c = document.getElementById("popupdiv");
  c.style.visibility = 'hidden';
  p = document.getElementById("popup");
  p.style.visibility = 'hidden';
  p = document.getElementById("send-ok");
  p.style.visibility = 'hidden';
  p = document.getElementById("send-err");
  p.style.visibility = 'hidden';
}