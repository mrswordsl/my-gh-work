function gbox ( f, mode ) 
{
  gray = ''; c = '#FFFFFF';
  if ( mode == 1 ) { gray = '_gray'; c = '#cacaca'; }    
  if (f && f.q) { 
    var q = f.q; 
    var n = navigator; 
    var l = location; 
    if (n.platform == 'Win32') { 
      q.style.cssText = 'border: 1px solid #7e9db9; padding: 2px;'; 
      } 
    var b = function() { 
        if (q.value == '') { 
           q.style.background = c + ' url(/images/google_watermark' + gray + '.gif) left no-repeat'; 
           } 
        }; 
    var f = function() { 
        q.style.background = '#FFFFFF'; 
        }; 
    q.onfocus = f; 
    q.onblur = b; 
    if (!/[&?]q=[^&]/.test(l.search)) { b(); } 
    } 
}
(function() 
{ var f = document.getElementById('cse-search-box'); 
  if ( f ) gbox ( f, 1 );
  f = document.getElementById('cse-search-boxx'); 
  if ( f ) gbox ( f, 0 );
})();