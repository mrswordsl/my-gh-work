function WeekPassed(year, mon, day)
{
   var today = new Date();
   var changeDate = new Date(year, mon-1, day);
   var daysPass = Math.round((today-changeDate)/86400000);
   return Math.floor(daysPass/7);
}

function AdjustColor() {
var divs = document.getElementsByTagName('div');
for (var i=0; i<divs.length; i++) {
  var s = divs[i].id;
  var hex = new String('0123456789ABCDEF');
  if( s.indexOf('up') == 0) {
    var day  = Number(s.substr(2,2));
    var mon  = Number(s.substr(5,2));
    var year = Number(s.substr(8,4));
    colG = 14 - WeekPassed(year, mon, day);
    if ( colG < 4 ) colG = 4;
    var c = hex.charAt(colG);
    divs[i].style.backgroundColor = '#00' + c + c + '00';
    }
  }
}
function ChooseFreshSign(d,mode) {
  var day  = Number(d.substr(0,2));
  var mon  = Number(d.substr(3,2));
  var year = Number(d.substr(6,4));
  var weeks = WeekPassed(year, mon, day);
  if ( weeks <= 4 )
     document.write('<img class="in" src="/images/fresh' + mode + '.gif" width="26" height="20" alt="Обновление!" border="0">');
}
