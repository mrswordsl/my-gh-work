function ShowSendForm() {
  var id = document.getElementById('sendiv');
  if ( id ) id.style.display = 'block';
}
function isValidEmailAddress ( str ) {
if ( str.indexOf(" ",0) != -1 || str.indexOf("@",3) == -1 || str.indexOf(".",6) == -1) {
  alert("Ошибка: " + str + ". Вы уверены, что это ваш электронный адрес?" );
  return false;
  }
return true;
}
String.prototype.trim = function () {
    return this.replace(/^\s*/, "").replace(/\s*$/, "");
}
function checkAll () {
form = document.sendform;
if ( form.elements[0].value == "" ) {
  alert ("Введите Ваше имя");
  form.elements[0].focus(); return false;
  }
if ( form.elements[1].value == "" ) {
  alert ("Пожалуйста введите Ваш электронный адрес (e-mail)");
  form.elements[1].focus(); return false;
  }
if ( form.elements[1].value != "" &&
     !isValidEmailAddress(form.elements[1].value) ) {
  form.elements[1].focus(); return false;
  }
var txt = form.elements[2].value.trim();
if ( txt == "" ) {
  alert ("Пожалуйста введите текст сообщения");
  form.elements[2].focus(); return false;
  }
if ( txt.search("href=") >= 0  ||  txt.search("http://") >= 0 ) {
  alert ("Ссылки в тексте сообщения запрещены.");
  form.elements[2].focus(); return false;
  }
return true;
}
function ShowThank ( )
{
try {
  var s = window.location.search;
  if (s.length == 0 ) return;
  var id = document.getElementById('thank-send');
  id.style.display = 'block';
}
catch(e) {}
}

function send_message(theme){
 new _uWnd('msgWin','Отправить сообщение',300,520,{
   shadow:1, header:1, min:1, close:1, resize:1, modal:1, popup:1, closeonesc:1,
   oncontent:function(){_uWnd.getbyname('msgWin').checksize();}
   },'<iframe src="http://kpolyakov.narod.ru/index/0-2/?'+theme+'" scrolling="no" style="width:520;height:300;margin:0px;border:0px;"></iframe>');
};
