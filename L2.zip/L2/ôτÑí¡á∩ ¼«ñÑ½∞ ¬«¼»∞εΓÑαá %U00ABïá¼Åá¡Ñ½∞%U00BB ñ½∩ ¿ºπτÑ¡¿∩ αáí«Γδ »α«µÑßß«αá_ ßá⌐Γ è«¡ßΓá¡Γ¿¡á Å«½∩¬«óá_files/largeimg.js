function GetComment ( hint )
{
    var s = hint;
    return s;
}
var wiEnlarge;
function Enlarge( fname, hint, type ) {
  var w=400, h=400;
  if (type == 'h') { w = 450; h = 338; }
  else if (type == 'v') { w = 338; h = 450; }
  else if (type.charAt(0) == 's') {
     w = parseInt(type.substring(1,4));
     h = parseInt(type.substring(4,7)); 
     }
  try { wiEnlarge.close(); } catch(err) {}
  var title = GetComment(hint);
  wiEnlarge = window.open('',"enlarge","width=" + w + ",height=" + h + ",top=0,left=0,toolbar=no,scrollbar=no,status=no,resize=no,menubar=no");
  wiEnlarge.document.open();
  wiEnlarge.document.write('<html><head><title>' + title + '</title></head>');
  wiEnlarge.document.write('<body style="padding:0;margin:0"><img src=' + fname);
  wiEnlarge.document.write(' width=' + w + ' height=' + h + ' alt="' + title + '"></body></html>');
  wiEnlarge.document.close();
  wiEnlarge.height = h;
  wiEnlarge.width = w;
  return false;
}
function parseDate ( d )
{
  var x=new Date ( d );
  var mon=x.getMonth()+1,
      day=x.getDate(),
      year=x.getFullYear();
  return day+'.'+mon+'.'+year;
}
function parseDateExt ( d )
{
  var x=new Date ( d );
  var mon=x.getMonth()+1,
      day=x.getDate(),
      year=x.getFullYear();
  switch ( mon ) {
    case 1: mon='января'; break;
    case 2: mon='февраля'; break;
    case 3: mon='марта'; break;
    case 4: mon='апреля'; break;
    case 5: mon='мая'; break;
    case 6: mon='июня'; break;
    case 7: mon='июля'; break;
    case 8: mon='августа'; break;
    case 9: mon='сентября'; break;
    case 10: mon='октября'; break;
    case 11: mon='ноября'; break;
    case 12: mon='декабря'; break;
    }
  return day+' '+mon+' '+year;
}
