var timeout_id;
var tooltip_node;
var timeout = 200;
var mouse_x = 0;
var mouse_y = 0;

var isDOM = document.getElementById; //DOM1 browser (MSIE 5+, Netscape 6, Opera 5+)
var isOpera = isOpera5 = window.opera && isDOM; //Opera 5+
var isOpera6 = isOpera && window.print; //Opera 6+
var isOpera7 = isOpera && document.readyState; //Opera 7+
var isMSIE = document.all && document.all.item && !isOpera; //Microsoft Internet Explorer 4+
var isMSIE5 = isDOM && isMSIE; //MSIE 5+
var isNetscape4 = document.layers; //Netscape 4.*
var isMozilla = isDOM && navigator.appName=="Netscape"; //Mozilla,  Netscape 6.*

if(isNetscape4) document.captureEvents(Event.MOUSEMOVE);
if(isMSIE || isOpera7){
	document.onmousemove = function(){
		mouse_x = event.clientX+document.body.scrollLeft;
		mouse_y = event.clientY+document.body.scrollTop;
		return true;
	}
}else if(isOpera){
	document.onmousemove = function(){
		mouse_x = event.clientX;
		mouse_y = event.clientY;
		return true;
	}
}else if(isNetscape4 || isMozilla){
	document.onmousemove = function(e){
		mouse_x = e.pageX;
		mouse_y = e.pageY;
		return true;
	}
}

function show_tooltip(tip_text) {
  if ( tip_text.charAt(0) == '%' ) return;
  tooltip_node = document.getElementById('tooltip');
  tooltip_node.style.left = mouse_x + 'px';
  tooltip_node.style.top = (mouse_y + 15) + 'px';
  html_text = "<div class='tooltip'>"+tip_text+"</div>";
  tooltip_node.innerHTML = html_text;
  timeout_id = setTimeout("_show_tooltip()", timeout);
}

function _show_tooltip() {
  tooltip_node.style.visibility = 'visible';
}

function hide_tooltip() {
  if (timeout_id) { clearTimeout(timeout_id) };
  tooltip_node = document.getElementById('tooltip');
  tooltip_node.style.visibility = 'hidden';
}